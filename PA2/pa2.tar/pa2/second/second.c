#include <stdio.h>
#include <stdlib.h>


//this function checks whether count is even or odd using bit operator
int cBits(unsigned short number) 
{ 
    int count = 0; 
   while (number) 
   { 
        count++; 
        number =number>> 1; 
     
    } 
    return count; 
} 
 

//

int checkPair(unsigned short number){

int bits=cBits(number);

unsigned short bit;
int countPair=0;
int count2=0;

  for (int c = 0; c<bits; c++)
  {

    bit = number >> c;

  if ((bit & 1)==0){

    count2=0;

}
    
    if ((bit & 1)==1){

    count2++;

     if(count2==2){

   countPair++;

   count2=0;
   }
     
    }
  

  }
return countPair;
}

char check(int count){

 if((count & 1)==1 ){
   return 'o';

  }else{
   return 'e';
  }


  return 'n';

}

int main(int argc,char* argv[])
{

 unsigned short decimal_num=atoi(argv[1]);
int bits=cBits(decimal_num);

 unsigned short result=0;
 int count=0;


//keep pulling the least significant bit and check if it is 1 or 0 if 1 increment the counter (need to make change her)
 //Converting decimalNumber to binary Number using bitwise operator

  for (int c = bits; c >= 0; c--)
  {
    result = decimal_num >> c;
    //printf(" result %u\n",result);
    if ((result & 1)==1){
     count++;
    }

  }



//Now when we get the counter we need to pull least significant bit store it somewhere and pull another bit if first pulled out bit was 1 and second bit was 1 increment the check pair counter

 char ck=check(count);
int countP=checkPair(decimal_num);




 if(ck=='e'){

printf("Even-Parity\t%d\n",countP);

 }else if(ck=='o'){

printf("Odd-Parity\t%d\n",countP);

 }

    return 0;
}

