#include <stdio.h>
#include<stdlib.h>



//********************************************************************************************************************************
int get(unsigned short x,int n){

int nBit=((x>>n)&1);

return nBit;
}



//This sets the nth bit so here x is the number n is the nth bit and v is to set that bit to whatever it wants to set it to
//**************************************************************************************************************
unsigned short set(unsigned short x,int n,int v){
 unsigned short y=0;
unsigned short newX=0;
unsigned short k=0;

if(v==0){
y=(~(1<<n));

newX= (x & y);

}else{
k=(1<<n);
newX=(k|x);

}
return newX;
}

//**************************************************************************************************************************************************
int comp(unsigned short x,int n){

int newBit=get(x,n);

if(newBit==1){

return set(x,n,0);
}
else{
return set(x,n,1);
} 

}


//**************************************************************************************************************
int main(int argc, char* argv[])
{


FILE *fp=fopen(argv[1],"r");
unsigned short x;
char c[20];
int n=0;
int v=0;
int newBit;

fscanf(fp,"%hu",&x);

//read the file till the end
while(!feof(fp)){
fscanf(fp,"%s\t%d\t%d\n",c,&n,&v);
if(c[0]=='s'){

x=set(x,n,v);
printf("%hu\n",x);
}else if(c[0]=='g'){
newBit=get(x,n);
printf("%d\n",newBit);
}else if(c[0]=='c'){
x=comp(x,n);
printf("%hu\n",x);
}

}
//closing file now
fclose(fp);
return 0;
}
