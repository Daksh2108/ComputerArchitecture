#include <stdio.h>
#include <stdlib.h>



//********************************************************************************************************************************
int get(unsigned short x,int n){

int nBit=((x>>n)&1);

return nBit;
}
//********************************************************************************************************************************

int main(int argc, char* argv[])
{



unsigned short number;

number=atoi(argv[1]);

int left=15;
int right=0;

while(left>=right){


if(get(number,left)!=get(number,right)){

printf("Not-Palindrome\n");
return 0;

}

left--;
right++;

}

printf("Is-Palindrome\n");

//*****************************************************************************************************************************************
}
