#include <stdio.h>
#include <stdlib.h>

int* sortArr(int inputArr[],int size){
//Declaring two array

int oddSize=0;
int evenSize=0;

for(int i=0;i<size;i++){
if(inputArr[i]%2==0){
evenSize=evenSize+1;
}else{

oddSize=oddSize+1;
}


}



int evenArr[evenSize];
int oddArr[oddSize];

int ek=0;
int odj=0;


for(int i=0;i<size;i++){

if(inputArr[i]%2==0){

evenArr[ek]=inputArr[i];

ek++;

}else{
//put it in the odd array

oddArr[odj]=inputArr[i];
odj++;
}

}


//Sorting the even array in ascending order

int tempEven=0;
for(int i=0;i<evenSize;i++){
for(int j=i+1;j<evenSize;j++){

if(evenArr[i] > evenArr[j]){
tempEven=evenArr[i];
evenArr[i]=evenArr[j];
evenArr[j]=tempEven;

}


}

}

int tempOdd=0;


for(int i=0;i<oddSize;i++){

for(int j=i+1;j<oddSize;j++){

if(oddArr[j]>oddArr[i]){
tempOdd=oddArr[j];
oddArr[j]=oddArr[i];
oddArr[i]=tempOdd;

}

}

}



//Now increase the size of the sorted array by the size of the oddArray;
//int finalArr[evenSize+oddSize];
 int *finalArr = malloc (sizeof (int) *(evenSize+oddSize));



int finalSize=0;
for(int i=0;i<evenSize;i++){

finalArr[i]=evenArr[i];
finalSize++;

}


int k=0;
for(int i=finalSize;i<evenSize+oddSize;i++){

finalArr[i]=oddArr[k];
k++;
finalSize++;

}

return finalArr;
}
int main(int argc, char**argv){

int size;
int arrnum;
//int inputn;

FILE *fp=fopen(argv[1],"r");

fscanf(fp,"%d \n",&size);
//declaring the size of that array

int inputArr[size];

for(int i=0;i<size;i++){

fscanf(fp,"%d\n",&arrnum);

inputArr[i]=arrnum;
}


int *nwArray=sortArr(inputArr,size);

for(int i=0; i<size;i++){

printf("%d\t",nwArray[i]);
}

//free the array 
free(nwArray);
//close the file

fclose(fp);

return 0;
}
