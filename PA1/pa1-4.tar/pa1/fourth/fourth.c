#include<stdlib.h>
#include<stdio.h>

int main(int argc, char**argv){

int row=0;
int col=0;

int item=0;
 FILE *fp=fopen(argv[1],"r");


if(fp==NULL){

//check condition here also
printf("error\n");

}else{

fscanf(fp,"%d %d",&row,&col);

//Make a matrix structure


//It allocates space for 2d array
 int **m1 = (int **)malloc(row * sizeof(int *)); 

for(int i=0;i<row;i++){
m1[i]=(int *)malloc(col * sizeof(int)); 

}


for(int i=0;i<row; i++){
for(int j=0;j<col; j++){

fscanf(fp,"%d",&item);

m1[i][j]=item;

}
}





int row2=0;
int col2=0;
int item2=0;

fscanf(fp,"%d %d",&row2,&col2);


//check for bad matrices and print and quit the program(Double check the condition here to make sure it is correct)

if(col!=row2){

printf("bad-matrices\n");


}else{

 int **m2 = (int **)malloc(row2 * sizeof(int *)); 

for(int i=0; i<row2; i++){

m2[i] = (int *)malloc(col2 * sizeof(int)); 

}

for(int i=0;i<row2;i++){

for(int j=0;j<col2;j++){

fscanf(fp,"%d",&item2);
m2[i][j]=item2;
}

}



//Creating the multMatrix 2*2

int **mult = (int **)malloc(row * sizeof(int *)); 

for(int i=0; i<row; i++){

mult[i] = (int *)malloc(col2 * sizeof(int)); 

}


//Now multiply the matrix

for(int i=0;i<row;i++){

for(int j=0; j<col2; j++){
   
  for(int t=0;t<col;t++){


mult[i][j]+=m1[i][t]*m2[t][j];

}
}
}

//Print the final array with tabs and a new line for new
for(int i=0; i<row; i++){
 for(int j=0; j<col2; j++){

printf("%d\t",mult[i][j]);
}

printf("\n");
}




// free m1 array




for(int i=0;i<row;i++){
free(m1[i]);

}
free(m1);
//free m2 array




for(int i=0; i<row2; i++){

free(m2[i]);

}

free(m2);
//free mult array


for(int i=0; i<row; i++){

free(mult[i]);
}

free(mult);
//close file
fclose(fp);





}


}










return 0;


}
