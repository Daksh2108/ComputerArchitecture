
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char**argv){

//A, E, I, O, U



//Stored the vowels in character 
char arr[11];
arr[0]='A';
arr[1]='a';
arr[2]='E';
arr[3]='e';
arr[4]='O';
arr[5]='o';
arr[6]='I';
arr[7]='i';
arr[8]='U';
arr[9]='u';

char *str;

for(int i=1; i<argc;i++){

str=argv[i];

int size=strlen(str);

for(int i=0; i<size;i++){
for(int j=0; j<11;j++)
{


if(str[i]==arr[j]){

printf("%c",str[i]);
}

}




}



}

return 0;
}
