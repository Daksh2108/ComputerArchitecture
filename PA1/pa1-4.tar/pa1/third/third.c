#include <stdlib.h>
#include <stdio.h>
struct node{
int data;
struct node *next;
};



// Declare the counter for the collision
int countCollision=0;
int countSearch=0;

//declared the size of the struct node arr

struct node *arr[10000];

void printHashTable(struct node *localArr[]){

for(int i=0;i<10000;i++){

struct node *ptr=localArr[i];


while(ptr!=NULL){

printf("%d\n",ptr->data);
ptr=ptr->next;

}
}


}




//Now use hash function as stated by the assignment requirements


int findIndex(int value, int arrSize){

//means input value is some negative number and we need to make it to positive number
if(value<0){
value =value+10000;

}
int index=value%arrSize;

return index;
}



//searches that specific index 
void search(struct node *localArr[], int value){


int sIndex=findIndex(value,10000);

struct node *ptr=localArr[sIndex];


int count=0;
while(ptr!=NULL){

if(ptr->data==value){

if(count==0){
countSearch=countSearch+1;
count++;
}


}

ptr=ptr->next;

}





}




void insert(int index,int data, struct node *localArr[]){


struct node *addNode = (struct node*)malloc(sizeof(struct node));

addNode->data=data;
addNode->next=NULL;



//if that index itself is null
if(localArr[index]==NULL){

localArr[index]=addNode;
}else{
//traverse the linked list to the end then add the node
struct node *ptr=localArr[index];
while(ptr->next!=NULL){

//duplicate value check, if it exist just end the program
if(ptr->data==data){
//free the node from the memory
free(addNode);

countCollision=countCollision+1;
return;


}
ptr=ptr->next;

}
countCollision=countCollision+1;
ptr->next=addNode;

}








}
//declare the array of type node with size of 10,000

//size should be 10,000 buckets


//create a function to get the end where we want to store the value 




void freeMemory(struct node *localArr[]){

for(int i=0;i<10000;i++){

struct node *ptr=localArr[i];
struct node *prev=NULL;


while(ptr!=NULL){
prev=ptr;
ptr=ptr->next;
free(prev);

}

}


}




int main(int argc, char**argv){

char c;
int val;

FILE *fp=fopen(argv[1],"r");


// reading the items from the file now



if(fp==NULL){

//Double check here also
printf("error");

}else{

while (!feof(fp)) {

    int number= fscanf(fp, "%c\t%d\n", &c, &val);

       //double check this condition we dont need it anyways
       if(number<2){
        
        printf("0");
          return 0;

        } 


        if (c == 'i') {
         int getIndex=findIndex(val,10000);
            insert(getIndex, val,arr);
        } else if (c == 's') {
            search(arr,val);
         
        }

    }

printf("%d\n",countCollision);
printf("%d\n",countSearch);



//free the memory of hash table

freeMemory(arr);

//close file

fclose(fp);



}



return 0;


}


