#include <stdlib.h>
#include <stdio.h>

struct bstNode{

struct bstNode *left;
struct bstNode *right;
int data;
};

//To print the bstNode tree, we need to print inorder to print all the tree which prints the tree in ascending order


void printBst(struct bstNode *root){
struct bstNode *ptr=root;

if(root==NULL){

return;
}



printBst(ptr->left);
printf("%d\t",ptr->data);
printBst(ptr->right);

}

void insert(struct bstNode**root, int data ){

// if root == null then set that as root 

struct bstNode *addNode = (struct bstNode*)malloc(sizeof(struct bstNode));
addNode->data=data;
addNode->right=NULL;
addNode->left=NULL;

struct bstNode *ptr=*root;

if(*root==NULL){
*root=addNode;
return;

}else if(data < ptr->data){

if(ptr->left==NULL){

ptr->left=addNode;
return;
}
free(addNode);
insert(&(ptr->left),data);

}else if(data > ptr->data){

if(ptr->right==NULL){

ptr->right=addNode;
return;
}

free(addNode);
insert(&(ptr->right),data);

}else if(ptr->data==data){
// If duplicate we dont insert the node but we need to clear it from memory
free(addNode);
}

//if data is less than the root then check if there is empty space to the left or not, if not recurse on the left

//if data is greater than the root then check if there is empty space to the right or not, if not recurse on the right

}


//free BST
void freeBst(struct bstNode* root){


if(root==NULL){
return;

}

freeBst(root->left);
freeBst(root->right);
free(root);


}



int main(int argc, char** argv){


//declaring the root as null
struct bstNode *root=NULL;

char c;
int val;

FILE *fp=fopen(argv[1],"r");

if(fp==NULL){

printf("error\n");


}else{

while (!feof(fp)) {

     int number=fscanf(fp, "%c\t%d\n", &c, &val);


      //Double check the condition here else it will go down and print when we dont have any input itself
       if(number<2){
        
        printf("0");
         return 0;

        } 


        if (c == 'i') {
            insert(&root, val);
        } 
    }

printBst(root);
freeBst(root);
fclose(fp);


}


return 0;
}
