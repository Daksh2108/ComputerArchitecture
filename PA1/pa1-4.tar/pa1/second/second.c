#include <stdio.h>
#include <stdlib.h>

struct node{
int data;
struct node *next;
};

//counts the number of item in the linked list
int count(struct node *front){

int count=0;

struct node *ptr=front;

while(ptr!=NULL){
count++;

ptr=ptr->next;
}

return count;
}

int checkArray(int arr[],int data,int size){



for(int i=0;i<size;i++){
if(arr[i]==data){

return 1;

}

}

return 0;

}
//displays the linked list 
void display(struct node *front){

int size=count(front);
int arr[size];
int arrSize=0;

struct node *ptr=front;

int i=0;
while(ptr!=NULL){
//store the data in the array 

int v=checkArray(arr,ptr->data,arrSize);

if(v==1){

ptr=ptr->next;

}else{
printf("%d\t",ptr->data);
arr[i]=ptr->data;
i++;
arrSize++;
ptr=ptr->next;
}
}

}


void delete(struct node **front,int target){
//Making sure to clear the memory when you delete

struct node *ptr=*front;
struct node *prev=NULL;
struct node *store=NULL;

while(ptr!=NULL){

if(ptr->data==target){

if(prev==NULL){
store=ptr;
ptr=ptr->next;
free(store);
*front=ptr;
return;
}else{

store=ptr;
prev->next=ptr->next;
free(store);
return;
}




}

prev=ptr;
ptr=ptr->next;
}



}


//deletes only first occurence


//inserts linked list in sorted order

void insert(struct node **front, int data){
 

//if front is null, add it to the linked list 

//make a node here

//struct bstNode *addNode = (struct bstNode*)malloc(sizeof(struct bstNode));
struct node *addNode=(struct node*)malloc(sizeof(struct node));
addNode->data=data;
addNode->next=NULL;

struct node *ptr=*front;
struct node *prev=NULL;
if(*front==NULL){

*front=addNode;

//means has only one node 

}else if(ptr->next==NULL){
if(addNode->data > ptr->data){
ptr->next=addNode;
}else{
addNode->next=ptr;
*front=addNode;
}
}else{

while(ptr!=NULL){

if(addNode->data < ptr->data){

break;

}

prev=ptr;
ptr=ptr->next;

}


if(prev==NULL){

//Means it found the node at the front of the list 
addNode->next=ptr;
*front=addNode;

//Now follow the logic here and build it 
}else{

addNode->next=prev->next;
prev->next=addNode;

}


}




}







int main(int argc, char **argv){


char ch;
int value;
struct node *front=NULL;


FILE *fp=fopen(argv[1],"r");

if(fp==NULL){

//Double check the condition here also
printf("error\n");

}else{

while (!feof(fp)) {

     int number=fscanf(fp, "%c\t%d\n", &ch, &value);


      //if file does not have element it prints 1

       if(number<2){
        
        printf("0\n");

        return 0;
         //Mistake found dont return 1
         //Double check here else it will go down and print unecessary values 
       

        } 


        if (ch == 'i') {
            insert(&front, value);
        } else if (ch == 'd') {
             delete(&front, value);
        }

    }

int counter=count(front);
printf("%d\n",counter);
display(front);



//free memory from heap


struct node* ptr=front;
struct node* prev=NULL;
while(ptr!=NULL){
prev=ptr;
ptr=ptr->next;
free(prev);

}


 fclose(fp);

}




return 0;



}
